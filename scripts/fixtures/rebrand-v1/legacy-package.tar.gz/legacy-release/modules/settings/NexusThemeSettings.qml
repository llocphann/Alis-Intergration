pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Layouts
import QtQuick.Dialogs
import Quickshell
import qs
import qs.services
import qs.modules.settings
import qs.modules.common
import qs.modules.common.widgets
import qs.modules.common.functions
SettingsCardSection {
 id:root
 title:Translation.tr("Nexus");icon:"diamond";expanded:true
 Component.onCompleted:NexusTheme.inspect()
 SettingsNativeDialogGuard {dialog:picker;dialogKey:"nexusConfigPicker"}
 FolderDialog {
  id:picker;title:"Nexus configuration folder"
  onAccepted:Config.setNestedValue("integrations.nexus.configPath",FileUtils.trimFileProtocol(String(selectedFolder)))
 }
 SettingsGroup {
  ContentSubsection {title:"Paths"}
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 6

                StyledText {
                    text: Translation.tr("Nexus vault folder")
                    color: Appearance.colors.colOnSurfaceVariant
                    font.pixelSize: Appearance.font.pixelSize.small
                }

                MaterialTextField {
                    id: todoNexusVaultPath
                    objectName: "nexusVaultPath"
                    Layout.fillWidth: true
                    wrapMode: TextInput.NoWrap
                    placeholderText: ""
                    font.pixelSize: Appearance.font.pixelSize.small
                    color: Appearance.colors.colOnSurface
                    text: Todo.sharedVaultPath
                    background: Rectangle {
                        color: Appearance.colors.colLayer1
                        radius: Appearance.rounding.small
                        border.width: todoNexusVaultPath.activeFocus ? 2 : 1
                        border.color: todoNexusVaultPath.activeFocus
                            ? Appearance.colors.colPrimary
                            : Appearance.colors.colLayer0Border
                    }
                    onEditingFinished: {
                        const value = text.trim()
                        const canonical = String(Config.options?.todo?.nexus?.vaultPath ?? "").trim()
                        const legacy = String(Config.options?.notes?.zettelkasten?.vaultPath ?? "").trim()
                        // Clear the old override so clearing the shared field
                        // never resurrects a separate Quick Notes vault.
                        const updates = {}
                        if (value !== canonical)
                            updates["todo.nexus.vaultPath"] = value
                        if (legacy.length > 0)
                            updates["notes.zettelkasten.vaultPath"] = ""
                        Config.setNestedValues(updates)
                    }

                    StyledToolTip {
                        text: Translation.tr("Shared by To-do and Zettelkasten.")
                    }
                }
            }


  StyledText {text:"Vault configuration folder";color:Appearance.colors.colSubtext}
  RowLayout {
   Layout.fillWidth:true
   MaterialTextField {objectName:"nexusVaultConfigPath";Layout.fillWidth:true;wrapMode:TextInput.NoWrap;text:Config.options?.integrations?.nexus?.configPath ?? "";placeholderText:".nexus (inside the shared vault)";onEditingFinished:Config.setNestedValue("integrations.nexus.configPath",text.trim())}
   RippleButtonWithIcon {materialIcon:"folder_open";mainText:Translation.tr("Browse");onClicked:picker.open()}
  }
  StyledText {text:"Application configuration folder";color:Appearance.colors.colSubtext}
  MaterialTextField {objectName:"nexusApplicationConfigPath";Layout.fillWidth:true;wrapMode:TextInput.NoWrap;text:Config.options?.integrations?.nexus?.applicationConfigPath ?? "";placeholderText:"Auto-detect Nexus's application config";onEditingFinished:Config.setNestedValue("integrations.nexus.applicationConfigPath",text.trim())}
  StyledText {text:"Application executable";color:Appearance.colors.colSubtext}
  RowLayout {
   Layout.fillWidth:true
   MaterialTextField {Layout.fillWidth:true;wrapMode:TextInput.NoWrap;text:Config.options?.integrations?.nexus?.applicationPath ?? "nexus";placeholderText:"nexus";onEditingFinished:Config.setNestedValue("integrations.nexus.applicationPath",text.trim() || "nexus")}
   DialogButton {buttonText:"Open Nexus";onClicked:Quickshell.execDetached([String(Config.options?.integrations?.nexus?.applicationPath || "nexus").trim()])}
  }
  ContentSubsection {title:Translation.tr("Auto theming")}
  SettingsSwitch {text:Translation.tr("Follow Alis colors");autoToggle:false;checked:NexusTheme.enabled;onToggledByUser:checked=>Config.setNestedValue("integrations.nexus.autoTheme",checked)}
  StyledText {
   Layout.fillWidth:true;wrapMode:Text.WordWrap
   color:NexusTheme.error ? Appearance.colors.colError : Appearance.colors.colSubtext
   text:NexusTheme.error || (NexusTheme.info.activeTheme ? NexusTheme.info.activeTheme+" · "+(NexusTheme.info.enabled ? Translation.tr("Applied") : Translation.tr("Not applied")) : Translation.tr("Choose a vault"))
   StyledToolTip {text:NexusTheme.info.snippetPath || ""}
  }
  RowLayout {
   DialogButton {buttonText:Translation.tr("Detect");enabled:!NexusTheme.busy;onClicked:NexusTheme.inspect()}
   DialogButton {buttonText:Translation.tr("Apply");enabled:!NexusTheme.busy;onClicked:NexusTheme.apply()}
   DialogButton {buttonText:Translation.tr("Disable");enabled:!NexusTheme.busy && (NexusTheme.info.enabled ?? false);onClicked:NexusTheme.restore()}
  }
  DialogButton {buttonText:"Use detected vault";visible:!Todo.sharedVaultPath && !!NexusTheme.info.vaultPath;onClicked:Config.setNestedValue("todo.nexus.vaultPath",NexusTheme.info.vaultPath)}
 }
}
